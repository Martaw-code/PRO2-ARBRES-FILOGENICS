var searchData=
[
  ['actualitzar_5fdistancies_5fclusters_5fwpgma_0',['actualitzar_distancies_clusters_wpgma',['../class_cjt___clusters.html#a45806f2852e1d3f203b2bf402e088c72',1,'Cjt_Clusters']]],
  ['actualitzar_5ftaula_5fdistancies_1',['actualitzar_Taula_Distancies',['../class_cjt___especies.html#aa5e93ac2d4049aa27c3d855c71fdbbc3',1,'Cjt_Especies']]],
  ['afegir_5fespecie_2',['afegir_especie',['../class_cjt___especies.html#a8c8f2a8908eaf49351382feded72430f',1,'Cjt_Especies']]],
  ['afegir_5ftaula_5fdistancies_3',['afegir_Taula_Distancies',['../class_cjt___especies.html#aff667b781d6e46762f7d1285ea36bd81',1,'Cjt_Especies']]]
];
