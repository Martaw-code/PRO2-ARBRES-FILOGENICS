var searchData=
[
  ['construcciÓ_20d_27un_20arbre_20filogÈnic_119',['CONSTRUCCIÓ D&apos;UN ARBRE FILOGÈNIC',['../index.html',1,'']]]
];
