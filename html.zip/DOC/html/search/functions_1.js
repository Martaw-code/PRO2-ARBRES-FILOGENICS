var searchData=
[
  ['borrar_5ftaula_5fdistancies_72',['borrar_Taula_Distancies',['../class_cjt___especies.html#ae35b7bb3d88bf287a5121c4ba0150722',1,'Cjt_Especies']]],
  ['buidar_5fconjunt_73',['buidar_conjunt',['../class_cjt___clusters.html#a11851dd050ffbcbea2bcedba4f542191',1,'Cjt_Clusters']]],
  ['buidar_5ftaula_74',['buidar_taula',['../class_cjt___clusters.html#acfdd76669766053122ad8d62d3884fec',1,'Cjt_Clusters']]],
  ['buit_75',['buit',['../class_cjt___clusters.html#a0cd648ebd5167d8619a7095cbee32232',1,'Cjt_Clusters']]]
];
