var searchData=
[
  ['llegir_99',['llegir',['../class_especie.html#a7384add391d2684c4fb6bdf8a535fba3',1,'Especie']]],
  ['llegir_5fconjunt_5fespecies_100',['llegir_conjunt_especies',['../class_cjt___especies.html#acc415ef38e2bce4a181f27d5a48fd453',1,'Cjt_Especies']]],
  ['longitud_5fk_101',['longitud_k',['../class_especie.html#a2995f95394402ef632e72ffd9fc4843c',1,'Especie']]]
];
