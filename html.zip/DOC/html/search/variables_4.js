var searchData=
[
  ['taula_5fdistancies_117',['Taula_Distancies',['../class_cjt___especies.html#a2b92045f333197afacbe04454a62f58a',1,'Cjt_Especies']]],
  ['taula_5fdistancies_5fc_118',['Taula_Distancies_C',['../class_cjt___clusters.html#a42111cb252fbea5294c1ef55229a5959',1,'Cjt_Clusters']]]
];
