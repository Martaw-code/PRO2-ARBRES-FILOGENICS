var searchData=
[
  ['k_115',['k',['../class_especie.html#a592c0ddeeebc786969f3040fbefea9df',1,'Especie']]],
  ['kmer_116',['kmer',['../class_especie.html#ab6740db160f2d7335a98fa8d9f745cbe',1,'Especie']]]
];
